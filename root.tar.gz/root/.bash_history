 poweroff
 poweroff
hostnamectl set-hostname TPServer
ping google.com
dhclient
ping google.com
dhclient -r
dhclient
ip a
dhclient -r && dhclient
ping google.com
echo "deb http://archive.debian.org/debian/ bullseye main" > /etc/apt/sources.list
echo "deb http://archive.debian.org/debian-security/ bullseye-security main" >> /etc/apt/sources.list
apt -o Acquire::Check-Valid-Until=false update
apt -o Acquire::Check-Valid-Until=false install openssh-server apache2 php libapache2-mod-php mariadb-server -y
echo "PermitRootLogin yes" >> /etc/ssh/sshd_config
systemctl restart ssh
ls
mv index.php logo.png /var/www/html/
ls
rm /var/www/html/index.html
mysql < db.sql
echo "<?php phipinfo(); ?>" > /var/www/html/test.php
sed -i's/display_errors = Off/display_errors = On/' /etc/php/*/apache2/php.ini
systemctl restart apache2
systemctl restart mariadb
tail -n 15 /var/log/apache2/error.log
chown -R www-data :www-data /var/www/html/
chown -R www-data:www-data /var/www/html/
chown -R 755 /var/www/html/
a2enmod php7.4
systemctl restart apache2
tail -n 10 /var/log/apache2/error.log 
apt install php-mysql -y
systemctl restart apache2
systemctl restart apache2
mkdir -p /root/.ssh
car /root/clave_ssh >> /root/.ssh/authorized_keys
cat /root/clave_ssh >> /root/.ssh/authorized_keys
cat /root/clave_ssh >> /root/ .ssh/authorized_keys
mkdir -p /root/.ssh
cat /root/clave_ssh >> /root/.ssh/authorized_keys
mkdir -p /root/ .ssh
cat /root/clave_ssh >> /root/ .ssh/authorized_keys
cat /root/clave_ssh >> /root/.ssh/authorized_keys
ls
ls
mkdir -p /root/.ssh
cat /root/clave_publica.pub >> /root/.ssh/authorized_keys
chmod 600 /root/.ssh/authorized_keys 
poweroff
fdisk /dev/sdb
fdisk /dev/sdb
fdisk /dev/sdb
mkfs.ext4 /dev/sdb1
mkfs.ext4 /dev/sdb2
lsblk
partprobe
udevadm settle
mkfs.ext4 /dev/sdb2
fdisk /dev/sdc
poweroff
fdisk /dev/sdc
lsblk
mkfs.ext4 /dev/sdc2
mkdir -p /www_dir
mkdir -p /backup_dir
mount /dev/sdc1 /www_dir
mkfs.ext4 /dev/sdc1
mount /dev/sdc1 /www_dir
mount /dev/sdc2 /backup_dir
df -h
nano /etc/fstab
echo "/dev/sdc1 /www_dir  ext4 defaults 0 2" >> /etc/fstab
echo "/dev/sdc2 /backup_dir  ext4 defaults 0 2" >> /etc/fstab
cat /etc/fstab
mount -a
sed -i 's|^/dev/sdb1|#/dev/sdb1|' /etc/fstab
cat /etc/fstab
mount -a
cat /proc/partitions > /proc/particion
cp index.php /www_dir/
find / -name "index.php"
nano /etc/apache2/sites-available/000-default.conf 
apt update
apt install nano -y
cp /var/www/html/index.php /www_dir/
cp /var/www/html/logo.png /www_dir/
nano /etc/apache2/sites-available/000-default.conf 
nano /etc/apache2/apache2.conf 
systemctl restart apache2
mount -o remount,rw /
nano /etc/fstab 
reboot
blkid
nano /etc/fstab 
mount -a
blkid
nano /etc/fstab 
mount -a
shutdown -h now
mkdir -p /opt/scripts
nano /opt/scripts/backup_full.sh
chmod +x /opt/scripts/backup_full.sh
/opt/scripts/backup_full.sh -help
/opt/scripts/backup_full.sh /var/log /backup_dir
ls -l /backup_dir
crontab -e
mkdir -p /var/logs
crontab -e
poweroff
poweroff
poweroff
