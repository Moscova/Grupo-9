#!/bin/bash


if [ "$1" == "-help" ] || [ $# -lt 2 ]; then
	echo "Uso: $0 <directorio_origen> <directorio_destino>"
	echo "Ejemplo: $0 /var/log /backup_dir"
	echo "Opciones: -help Muestra este menu"
	exit 0
fi


ORIGEN="$1"
DESTINO="$2"


if [ ! -d "$ORIGEN" ]; then
	echo "ERROR: El directorio origen '$ORIGEN' no existe"
	exit 1
fi



if [ ! -d "$DESTINO" ]; then
	echo "ERROR: El directorio destino '$DESTINO' no existe"
	exit 1
fi


NOMBRE_BASE=$(basename "$ORIGEN")
FECHA=$(date +%Y%m%d)
NOMBRE_ARCHIVO="${NOMBRE_BASE}_bkp_${FECHA}.tar.gz"

tar -czf "${DESTINO}/${NOMBRE_ARCHIVO}" "$ORIGEN" 2>/dev/null


if [ $? -eq 0 ]; then
	echo "Backup creado con exito  en el destino: ${DESTINO}/${NOMBRE_ARCHIVO}"
else
	echo "ERROR: No se pudo crear el backup"
	exit 1
fi
