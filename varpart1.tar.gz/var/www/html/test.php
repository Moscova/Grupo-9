<?php phipinfo(); ?>
